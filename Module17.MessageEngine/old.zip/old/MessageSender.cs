namespace FactoryMethodRealExample
{
    /// <summary>
    /// Абстрактный класс для рассылок
    /// </summary>
    abstract class MessageSender
    {
        public string To { get; set; }
 
        public MessageSender (string _to)
        { 
            To = _to; 
        }
        
        // Фабричный метод
        abstract public Message Send(string text);
    }
}